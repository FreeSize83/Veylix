@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

set "FW=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319"
if not exist "%FW%\csc.exe" set "FW=%WINDIR%\Microsoft.NET\Framework\v4.0.30319"
if not exist "%FW%\csc.exe" goto nocsc

if not exist dist mkdir dist
echo Сборка BeeBot.exe ...
"%FW%\csc.exe" /nologo /codepage:65001 /target:winexe /optimize+ /out:dist\BeeBot.exe /win32icon:BeeBot.ico /win32manifest:BeeBot.manifest /resource:zapret.zip,zapret.zip /lib:"%FW%\WPF" /r:PresentationCore.dll /r:PresentationFramework.dll /r:WindowsBase.dll /r:System.Xaml.dll /r:System.Core.dll /r:System.Drawing.dll /r:System.Windows.Forms.dll /r:System.IO.Compression.dll /r:System.IO.Compression.FileSystem.dll src\*.cs
if errorlevel 1 goto fail

echo.
echo ГОТОВО: %~dp0dist\BeeBot.exe
echo Запускайте двойным кликом (запросит права администратора).
pause
exit /b 0

:nocsc
echo Не найден csc.exe из .NET Framework 4.x. Он есть в Windows 10/11 по умолчанию.
pause
exit /b 1

:fail
echo.
echo ОШИБКА СБОРКИ. Скопируйте текст ошибок выше и отправьте мне.
pause
exit /b 1
