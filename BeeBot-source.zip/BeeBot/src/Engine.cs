﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BeeBot
{
    public class Strategy
    {
        public string Display;   // например "ALT3"
        public string BatPath;   // полный путь к исходному .bat (он не изменяется)
        public string Note;      // короткое описание
        public bool Warn;        // помечена автором как "NOT RECOMMENDED"
    }

    public class Engine
    {
        // Меняйте при обновлении встроенного архива zapret.zip, чтобы файлы переизвлеклись
        public const string DataVersion = "1.10.3-r1";

        public string Root, Bin, Lists, Utils;
        public Process Proc;
        public Strategy Current;
        public DateTime StartedAt;

        public event Action<string, string> Log;   // (уровень, текст)
        public event Action Exited;                // winws.exe завершился сам

        public string GameMode = "disabled";       // disabled | all | tcp | udp
        string tcpRange = "1024-65535";
        string udpRange = "1024-65535";

        public Engine(string root)
        {
            Root = root;
            Bin = Path.Combine(root, "bin");
            Lists = Path.Combine(root, "lists");
            Utils = Path.Combine(root, "utils");
            Directory.CreateDirectory(Lists);
            Directory.CreateDirectory(Utils);
            LoadGameMode();
        }

        void L(string level, string text)
        {
            Action<string, string> h = Log;
            if (h != null) h(level, text);
        }

        // ---------- расположение файлов zapret ----------

        public static string Locate()
        {
            string exeDir = AppDomain.CurrentDomain.BaseDirectory;
            string a = Path.Combine(exeDir, "zapret");
            if (File.Exists(Path.Combine(a, "bin", "winws.exe"))) return a;
            if (File.Exists(Path.Combine(exeDir, "bin", "winws.exe"))) return exeDir;
            return ExtractEmbedded();
        }

        static string ExtractEmbedded()
        {
            string target = Path.Combine(Settings.Dir, "zapret");
            string marker = Path.Combine(target, ".version");
            string exe = Path.Combine(target, "bin", "winws.exe");
            if (File.Exists(marker) && File.Exists(exe) && File.ReadAllText(marker).Trim() == DataVersion)
                return target;

            Directory.CreateDirectory(target);
            Assembly asm = Assembly.GetExecutingAssembly();
            using (Stream s = asm.GetManifestResourceStream("zapret.zip"))
            {
                if (s == null) throw new InvalidOperationException("Ресурс zapret.zip не найден внутри exe.");
                using (ZipArchive zip = new ZipArchive(s, ZipArchiveMode.Read))
                {
                    foreach (ZipArchiveEntry e in zip.Entries)
                    {
                        if (e.FullName.EndsWith("/") || e.FullName.EndsWith("\\")) continue;
                        string dest = Path.Combine(target, e.FullName.Replace('/', '\\'));
                        string name = Path.GetFileName(dest).ToLowerInvariant();
                        bool keep = File.Exists(dest) &&
                                    (name.EndsWith("-user.txt") || name == "ipset-all.txt" || name == "game_filter.enabled");
                        if (keep) continue;
                        try
                        {
                            Directory.CreateDirectory(Path.GetDirectoryName(dest));
                            e.ExtractToFile(dest, true);
                        }
                        catch { }
                    }
                }
            }
            File.WriteAllText(marker, DataVersion);
            return target;
        }

        // ---------- стратегии (читаем оригинальные .bat, ничего в них не меняя) ----------

        public List<Strategy> LoadStrategies()
        {
            List<Strategy> list = new List<Strategy>();
            foreach (string f in Directory.GetFiles(Root, "general*.bat"))
            {
                string baseName = Path.GetFileNameWithoutExtension(f);
                Match m = Regex.Match(baseName, @"\((.+)\)");
                Strategy s = new Strategy();
                s.BatPath = f;
                s.Display = m.Success ? m.Groups[1].Value : "general";

                string d = s.Display;
                if (d == "general") s.Note = "Основная";
                else if (Regex.IsMatch(d, @"^ALT\d*$")) s.Note = "Альтернативная";
                else if (d.IndexOf("FAKE TLS AUTO", StringComparison.OrdinalIgnoreCase) >= 0) s.Note = "Fake TLS · авто";
                else if (d.IndexOf("SIMPLE FAKE", StringComparison.OrdinalIgnoreCase) >= 0) s.Note = "Simple fake";
                else if (d.IndexOf("EXP", StringComparison.OrdinalIgnoreCase) >= 0) s.Note = "Экспериментальная";
                else s.Note = "Стратегия";

                try
                {
                    string head = File.ReadAllText(f, Encoding.UTF8);
                    if (head.IndexOf("NOT RECOMMENDED", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        s.Warn = true;
                        s.Note = "Не рекомендуется";
                    }
                }
                catch { }
                list.Add(s);
            }
            list.Sort(CompareStrategies);
            return list;
        }

        static void Key(string d, out int g, out int n)
        {
            g = 2; n = 0;
            if (d == "general") { g = 0; return; }
            Match m = Regex.Match(d, @"^ALT(\d*)$");
            if (m.Success)
            {
                g = 1;
                n = m.Groups[1].Value.Length == 0 ? 1 : int.Parse(m.Groups[1].Value);
            }
        }

        static int CompareStrategies(Strategy a, Strategy b)
        {
            int ga, na, gb, nb;
            Key(a.Display, out ga, out na);
            Key(b.Display, out gb, out nb);
            if (ga != gb) return ga.CompareTo(gb);
            if (na != nb) return na.CompareTo(nb);
            return string.Compare(a.Display, b.Display, StringComparison.OrdinalIgnoreCase);
        }

        static string Sub(string s, string key, string val)
        {
            return Regex.Replace(s, Regex.Escape(key), delegate(Match m) { return val; }, RegexOptions.IgnoreCase);
        }

        // Берём из .bat всё, что идёт после winws.exe" — так же делает и сам service.bat
        public string BuildArgs(Strategy s)
        {
            string[] lines = File.ReadAllLines(s.BatPath, Encoding.UTF8);
            StringBuilder sb = new StringBuilder();
            bool found = false;
            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i].Trim();
                if (!found)
                {
                    if (!line.StartsWith("start ", StringComparison.OrdinalIgnoreCase)) continue;
                    int k = line.IndexOf("winws.exe\"", StringComparison.OrdinalIgnoreCase);
                    if (k < 0) continue;
                    found = true;
                    line = line.Substring(k + 10).Trim();
                }
                bool cont = line.EndsWith("^");
                if (cont) line = line.Substring(0, line.Length - 1).Trim();
                if (line.Length > 0)
                {
                    if (sb.Length > 0) sb.Append(' ');
                    sb.Append(line);
                }
                if (!cont) break;
            }
            if (!found) return null;

            string args = sb.ToString();
            args = Sub(args, "%BIN%", Bin + "\\");
            args = Sub(args, "%LISTS%", Lists + "\\");
            args = Sub(args, "%GameFilterTCP%", GameTcp);
            args = Sub(args, "%GameFilterUDP%", GameUdp);
            args = Sub(args, "%GameFilter%", GameTcp);
            return args;
        }

        // ---------- запуск / остановка ----------

        public bool IsRunning
        {
            get
            {
                try { return Proc != null && !Proc.HasExited; }
                catch { return false; }
            }
        }

        public bool ExternalRunning()
        {
            try { return !IsRunning && Process.GetProcessesByName("winws").Length > 0; }
            catch { return false; }
        }

        public void EnsureUserLists()
        {
            string a = Path.Combine(Lists, "ipset-exclude-user.txt");
            string b = Path.Combine(Lists, "list-general-user.txt");
            string c = Path.Combine(Lists, "list-exclude-user.txt");
            if (!File.Exists(a)) File.WriteAllText(a, "203.0.113.113/32\r\n");
            if (!File.Exists(b)) File.WriteAllText(b, "# Never leave this file empty\r\ndomain.example.abc\r\n");
            if (!File.Exists(c)) File.WriteAllText(c, "domain.example.abc\r\n");
            string ip = Path.Combine(Lists, "ipset-all.txt");
            if (!File.Exists(ip)) File.WriteAllText(ip, "");
        }

        public bool Start(Strategy s)
        {
            Stop();
            try
            {
                EnsureUserLists();
                string args = BuildArgs(s);
                if (args == null)
                {
                    L("err", "Не удалось найти строку запуска winws.exe в " + Path.GetFileName(s.BatPath));
                    return false;
                }

                string exe = Path.Combine(Bin, "winws.exe");
                if (!File.Exists(exe))
                {
                    L("err", "Не найден " + exe + " (антивирус мог удалить файл).");
                    return false;
                }

                ProcessStartInfo psi = new ProcessStartInfo(exe, args);
                psi.WorkingDirectory = Bin;
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;                 // <- никаких дополнительных окон
                psi.WindowStyle = ProcessWindowStyle.Hidden;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                psi.StandardOutputEncoding = Encoding.UTF8;
                psi.StandardErrorEncoding = Encoding.UTF8;

                Process p = new Process();
                p.StartInfo = psi;
                p.EnableRaisingEvents = true;
                p.OutputDataReceived += delegate(object o, DataReceivedEventArgs e)
                {
                    if (!string.IsNullOrWhiteSpace(e.Data)) L("proc", e.Data.Trim());
                };
                p.ErrorDataReceived += delegate(object o, DataReceivedEventArgs e)
                {
                    if (!string.IsNullOrWhiteSpace(e.Data)) L("proc", e.Data.Trim());
                };
                p.Exited += delegate(object o, EventArgs e)
                {
                    if (object.ReferenceEquals(Proc, p))
                    {
                        Proc = null;
                        Current = null;
                        Action h = Exited;
                        if (h != null) h();
                    }
                };

                p.Start();
                p.BeginOutputReadLine();
                p.BeginErrorReadLine();
                Proc = p;
                Current = s;
                StartedAt = DateTime.Now;
                return true;
            }
            catch (Exception ex)
            {
                L("err", "Ошибка запуска: " + ex.Message);
                return false;
            }
        }

        public void Stop()
        {
            Process p = Proc;
            Proc = null;
            Current = null;
            if (p != null)
            {
                try
                {
                    if (!p.HasExited) p.Kill();
                    p.WaitForExit(3000);
                }
                catch { }
            }
            KillStray();
            CleanupDivert();
        }

        public void KillStray()
        {
            try
            {
                foreach (Process x in Process.GetProcessesByName("winws"))
                {
                    try { x.Kill(); x.WaitForExit(2000); }
                    catch { }
                }
            }
            catch { }
        }

        void CleanupDivert()
        {
            string o;
            // как в service.bat: net stop ждёт полной остановки драйвера, затем удаляем службу
            RunHidden("net.exe", "stop WinDivert", 15000, out o);
            RunHidden("sc.exe", "delete WinDivert", 8000, out o);
        }

        public static int RunHidden(string file, string args, int timeoutMs, out string output)
        {
            output = "";
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo(file, args);
                psi.UseShellExecute = false;
                psi.CreateNoWindow = true;
                psi.RedirectStandardOutput = true;
                psi.RedirectStandardError = true;
                using (Process p = Process.Start(psi))
                {
                    if (!p.WaitForExit(timeoutMs))
                    {
                        try { p.Kill(); } catch { }
                        return -1;
                    }
                    output = p.StandardOutput.ReadToEnd() + p.StandardError.ReadToEnd();
                    return p.ExitCode;
                }
            }
            catch (Exception ex)
            {
                output = ex.Message;
                return -2;
            }
        }

        // ---------- игровой фильтр (формат файла совместим с service.bat) ----------

        string GameFlagFile { get { return Path.Combine(Utils, "game_filter.enabled"); } }

        public string GameTcp
        {
            get { return (GameMode == "all" || GameMode == "tcp") ? tcpRange : "12"; }
        }

        public string GameUdp
        {
            get { return (GameMode == "all" || GameMode == "udp") ? udpRange : "12"; }
        }

        static bool ValidRange(string v)
        {
            return Regex.IsMatch(v, @"^\d+(-\d+)?(,\d+(-\d+)?)*$");
        }

        void LoadGameMode()
        {
            GameMode = "disabled";
            try
            {
                if (!File.Exists(GameFlagFile)) return;
                foreach (string raw in File.ReadAllLines(GameFlagFile))
                {
                    string line = raw.Trim();
                    if (line.Length == 0) continue;
                    string k = line, v = "";
                    int i = line.IndexOf('=');
                    if (i >= 0) { k = line.Substring(0, i).Trim(); v = line.Substring(i + 1).Trim(); }
                    k = k.ToLowerInvariant();
                    if (k == "mode") GameMode = v.ToLowerInvariant();
                    else if (k == "all") GameMode = "all";
                    else if (k == "udp") { if (v.Length == 0) GameMode = "udp"; else if (ValidRange(v)) udpRange = v; }
                    else if (k == "tcp") { if (v.Length == 0) GameMode = "tcp"; else if (ValidRange(v)) tcpRange = v; }
                }
                if (GameMode != "all" && GameMode != "tcp" && GameMode != "udp") GameMode = "disabled";
            }
            catch { GameMode = "disabled"; }
        }

        public void SetGameMode(string mode)
        {
            GameMode = mode;
            try
            {
                if (mode == "disabled")
                {
                    if (File.Exists(GameFlagFile)) File.Delete(GameFlagFile);
                    return;
                }
                StringBuilder sb = new StringBuilder();
                sb.Append("mode=" + mode + "\r\n");
                if (tcpRange != "1024-65535") sb.Append("tcp=" + tcpRange + "\r\n");
                if (udpRange != "1024-65535") sb.Append("udp=" + udpRange + "\r\n");
                File.WriteAllText(GameFlagFile, sb.ToString());
            }
            catch (Exception ex) { L("err", "Не удалось сохранить игровой фильтр: " + ex.Message); }
        }

        public string NextGameMode()
        {
            if (GameMode == "disabled") return "all";
            if (GameMode == "all") return "tcp";
            if (GameMode == "tcp") return "udp";
            return "disabled";
        }

        // ---------- режим IPSet (та же логика, что в service.bat) ----------

        string IpsetFile { get { return Path.Combine(Lists, "ipset-all.txt"); } }

        public string GetIpsetMode()
        {
            try
            {
                if (!File.Exists(IpsetFile)) return "any";
                string t = File.ReadAllText(IpsetFile);
                if (t.Trim().Length == 0) return "any";
                if (t.Contains("203.0.113.113/32")) return "none";
                return "loaded";
            }
            catch { return "any"; }
        }

        // none -> any -> loaded -> none. Возвращает текст ошибки или null.
        public string CycleIpset()
        {
            try
            {
                string list = IpsetFile;
                string backup = list + ".backup";
                string mode = GetIpsetMode();
                if (mode == "loaded")
                {
                    if (File.Exists(backup)) File.Delete(backup);
                    File.Move(list, backup);
                    File.WriteAllText(list, "203.0.113.113/32\r\n");
                }
                else if (mode == "none")
                {
                    File.WriteAllText(list, "");
                }
                else
                {
                    if (!File.Exists(backup)) return "Нет сохранённого списка IPSet. Сначала нажмите «Обновить IPSet».";
                    if (File.Exists(list)) File.Delete(list);
                    File.Move(backup, list);
                }
                return null;
            }
            catch (Exception ex) { return ex.Message; }
        }

        public string UpdateIpset()
        {
            string url = "https://raw.githubusercontent.com/Flowseal/zapret-discord-youtube/refs/heads/main/.service/ipset-service.txt";
            string tmp = IpsetFile + ".download";
            try
            {
                ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                using (WebClient wc = new WebClient())
                {
                    wc.DownloadFile(url, tmp);
                }
                if (new FileInfo(tmp).Length < 1000)
                {
                    File.Delete(tmp);
                    return "Скачанный файл подозрительно мал — список не заменён.";
                }
                File.Copy(tmp, IpsetFile, true);
                File.Delete(tmp);
                return null;
            }
            catch (Exception ex)
            {
                try { if (File.Exists(tmp)) File.Delete(tmp); } catch { }
                return ex.Message;
            }
        }

        // ---------- автозапуск через планировщик (без UAC при входе в систему) ----------

        public static bool IsAutorun()
        {
            string o;
            return RunHidden("schtasks.exe", "/Query /TN BeeBotLauncher", 10000, out o) == 0;
        }

        public static string SetAutorun(bool on, string exe)
        {
            string o;
            int code;
            if (on)
                code = RunHidden("schtasks.exe",
                    "/Create /TN BeeBotLauncher /SC ONLOGON /RL HIGHEST /F /TR \"\\\"" + exe + "\\\" --autostart\"",
                    20000, out o);
            else
                code = RunHidden("schtasks.exe", "/Delete /TN BeeBotLauncher /F", 20000, out o);
            return code == 0 ? null : (string.IsNullOrEmpty(o) ? "код " + code : o.Trim());
        }

        // ---------- проверка доступности сайта ----------

        public static Task<bool> TestUrl(string url, int timeoutMs)
        {
            return Task.Run(delegate()
            {
                try
                {
                    ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
                    HttpWebRequest req = (HttpWebRequest)WebRequest.Create(url);
                    req.Timeout = timeoutMs;
                    req.ReadWriteTimeout = timeoutMs;
                    req.Proxy = null;
                    req.UserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) BeeBot";
                    using (WebResponse r = req.GetResponse())
                    {
                        return true;
                    }
                }
                catch (WebException ex)
                {
                    // Любой HTTP-ответ (даже 403/404) = соединение до сайта прошло
                    if (ex.Response != null)
                    {
                        try { ex.Response.Close(); } catch { }
                        return true;
                    }
                    return false;
                }
                catch
                {
                    return false;
                }
            });
        }
    }
}
