﻿using System;
using System.IO;
using System.Threading;
using System.Windows;
using System.Windows.Threading;

namespace BeeBot
{
    public static class Program
    {
        [STAThread]
        public static void Main(string[] args)
        {
            bool created;
            Mutex mutex = new Mutex(true, "Global\\BeeBotLauncher_v1", out created);
            if (!created)
            {
                MessageBox.Show("BeeBot уже запущен. Проверьте значок в трее.", "BeeBot");
                return;
            }

            bool auto = false;
            foreach (string a in args)
            {
                if (a == "--autostart") auto = true;
            }

            Application app = new Application();
            app.DispatcherUnhandledException += delegate(object s, DispatcherUnhandledExceptionEventArgs e)
            {
                try
                {
                    Directory.CreateDirectory(Settings.Dir);
                    File.AppendAllText(Path.Combine(Settings.Dir, "crash.log"),
                        DateTime.Now.ToString() + "\r\n" + e.Exception.ToString() + "\r\n\r\n");
                }
                catch { }
                MessageBox.Show(e.Exception.Message, "BeeBot — ошибка");
                e.Handled = true;
            };

            app.Run(new MainWindow(auto));
            GC.KeepAlive(mutex);
        }
    }
}
