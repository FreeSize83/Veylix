﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shapes;

namespace BeeBot
{
    public static class Theme
    {
        public static readonly FontFamily Ui = new FontFamily("Segoe UI");
        public static readonly FontFamily Icons = new FontFamily("Segoe MDL2 Assets");

        public const string Ink = "#4A3B35";      // основной текст
        public const string Muted = "#9A8A80";    // второстепенный текст
        public const string Cream = "#F8F1E8";    // панели
        public const string Purple = "#8B6BD6";
        public const string Green = "#7DBE6B";
        public const string Orange = "#F0A35E";
        public const string Red = "#E58C84";

        public static Color C(string hex)
        {
            return (Color)ColorConverter.ConvertFromString(hex);
        }

        public static SolidColorBrush B(string hex)
        {
            SolidColorBrush b = new SolidColorBrush(C(hex));
            b.Freeze();
            return b;
        }

        // вертикальный градиент сверху вниз
        public static LinearGradientBrush G(string top, string bottom)
        {
            LinearGradientBrush g = new LinearGradientBrush(C(top), C(bottom), 90.0);
            g.Freeze();
            return g;
        }

        public static DropShadowEffect Shadow(double blur, double depth, double opacity)
        {
            DropShadowEffect e = new DropShadowEffect();
            e.Color = C("#7A4A2B");
            e.BlurRadius = blur;
            e.ShadowDepth = depth;
            e.Direction = 270;
            e.Opacity = opacity;
            return e;
        }

        public static TextBlock T(string text, double size, string color, bool bold)
        {
            TextBlock t = new TextBlock();
            t.Text = text;
            t.FontFamily = Ui;
            t.FontSize = size;
            t.Foreground = B(color);
            t.FontWeight = bold ? FontWeights.SemiBold : FontWeights.Normal;
            return t;
        }

        // иконка из шрифта Segoe MDL2 Assets
        public static TextBlock Icon(int code, double size, string color)
        {
            TextBlock t = new TextBlock();
            t.Text = char.ConvertFromUtf32(code);
            t.FontFamily = Icons;
            t.FontSize = size;
            t.Foreground = B(color);
            t.HorizontalAlignment = HorizontalAlignment.Center;
            t.VerticalAlignment = VerticalAlignment.Center;
            return t;
        }

        // мягкая «глиняная» панель (тень вынесена на отдельный слой, чтобы не тормозила прокрутка)
        public static Plate Panel(string bg, double radius)
        {
            return new Plate(bg, radius);
        }

        // круглый значок-статус: 0 ожидание, 1 в процессе, 2 успех, 3 ошибка
        public static Border Badge(double size)
        {
            Border b = new Border();
            b.Width = size;
            b.Height = size;
            b.CornerRadius = new CornerRadius(size / 2.0);
            TextBlock t = T("", size * 0.55, "#FFFFFF", true);
            t.HorizontalAlignment = HorizontalAlignment.Center;
            t.VerticalAlignment = VerticalAlignment.Center;
            b.Child = t;
            ApplyBadge(b, 0);
            return b;
        }

        public static void ApplyBadge(Border b, int state)
        {
            TextBlock t = (TextBlock)b.Child;
            if (state == 1) { b.Background = B(Orange); t.Text = "…"; }
            else if (state == 2) { b.Background = B(Green); t.Text = "✓"; }
            else if (state == 3) { b.Background = B(Red); t.Text = "✕"; }
            else { b.Background = B("#D9CDBF"); t.Text = ""; }
        }

        // маленькая пчёлка для логотипа
        public static FrameworkElement Bee(double s)
        {
            Canvas c = new Canvas();
            c.Width = s;
            c.Height = s;

            Ellipse w1 = new Ellipse();
            w1.Width = s * 0.34; w1.Height = s * 0.42;
            w1.Fill = B("#DDEFF9"); w1.Stroke = B("#9CC7E0"); w1.StrokeThickness = 1;
            Canvas.SetLeft(w1, s * 0.20); Canvas.SetTop(w1, s * 0.02);
            w1.RenderTransformOrigin = new Point(0.5, 0.5);
            w1.RenderTransform = new RotateTransform(-18);
            c.Children.Add(w1);

            Ellipse w2 = new Ellipse();
            w2.Width = s * 0.34; w2.Height = s * 0.42;
            w2.Fill = B("#DDEFF9"); w2.Stroke = B("#9CC7E0"); w2.StrokeThickness = 1;
            Canvas.SetLeft(w2, s * 0.46); Canvas.SetTop(w2, s * 0.02);
            w2.RenderTransformOrigin = new Point(0.5, 0.5);
            w2.RenderTransform = new RotateTransform(18);
            c.Children.Add(w2);

            Ellipse body = new Ellipse();
            body.Width = s * 0.80; body.Height = s * 0.58;
            body.Fill = G("#FFD25A", "#F2A93B");
            body.Stroke = B("#7A5028"); body.StrokeThickness = 1;
            Canvas.SetLeft(body, s * 0.10); Canvas.SetTop(body, s * 0.30);
            c.Children.Add(body);

            double[] xs = new double[] { 0.38, 0.54, 0.70 };
            foreach (double x in xs)
            {
                Rectangle r = new Rectangle();
                r.Width = s * 0.09; r.Height = s * 0.40;
                r.RadiusX = s * 0.04; r.RadiusY = s * 0.04;
                r.Fill = B("#4A3B35");
                Canvas.SetLeft(r, s * x - s * 0.045);
                Canvas.SetTop(r, s * 0.39);
                c.Children.Add(r);
            }

            Ellipse eye = new Ellipse();
            eye.Width = s * 0.07; eye.Height = s * 0.07;
            eye.Fill = B("#4A3B35");
            Canvas.SetLeft(eye, s * 0.2); Canvas.SetTop(eye, s * 0.5);
            c.Children.Add(eye);
            return c;
        }
    }

    public class Plate : Grid
    {
        Border face;

        public Plate(string bg, double radius)
        {
            Border shadow = new Border();
            shadow.Background = Theme.B(bg);
            shadow.CornerRadius = new CornerRadius(radius);
            shadow.Effect = Theme.Shadow(18, 5, 0.22);
            Children.Add(shadow);

            face = new Border();
            face.Background = Theme.B(bg);
            face.CornerRadius = new CornerRadius(radius);
            face.BorderBrush = Theme.B("#CCFFFFFF");
            face.BorderThickness = new Thickness(1.5);
            Children.Add(face);
        }

        public UIElement Child
        {
            get { return face.Child; }
            set { face.Child = value; }
        }
    }

    // Кнопка в стиле «глины»: мягкая тень, блик по краю, нажатие слегка уменьшает её
    public class ClayButton : Border
    {
        public event EventHandler Click;
        Brush normal;
        Brush hover;
        bool pressed;

        public ClayButton(Brush bg, Brush hoverBg, double radius)
        {
            normal = bg;
            hover = hoverBg;
            Background = bg;
            CornerRadius = new CornerRadius(radius);
            BorderBrush = Theme.B("#CCFFFFFF");
            BorderThickness = new Thickness(1.5);
            Effect = Theme.Shadow(12, 4, 0.25);
            Cursor = Cursors.Hand;
            RenderTransformOrigin = new Point(0.5, 0.5);
            IsEnabledChanged += delegate(object s, DependencyPropertyChangedEventArgs e)
            {
                Opacity = IsEnabled ? 1.0 : 0.55;
            };
        }

        public void SetBrushes(Brush bg, Brush hoverBg)
        {
            normal = bg;
            hover = hoverBg;
            Background = (IsMouseOver && hover != null) ? hover : normal;
        }

        protected override void OnMouseEnter(MouseEventArgs e)
        {
            base.OnMouseEnter(e);
            if (hover != null) Background = hover;
        }

        protected override void OnMouseLeave(MouseEventArgs e)
        {
            base.OnMouseLeave(e);
            Background = normal;
        }

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonDown(e);
            pressed = true;
            CaptureMouse();
            RenderTransform = new ScaleTransform(0.96, 0.96);
            e.Handled = true;
        }

        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e)
        {
            base.OnMouseLeftButtonUp(e);
            if (!pressed) return;
            pressed = false;
            ReleaseMouseCapture();
            RenderTransform = Transform.Identity;
            Point p = e.GetPosition(this);
            if (p.X >= 0 && p.Y >= 0 && p.X <= ActualWidth && p.Y <= ActualHeight)
            {
                EventHandler h = Click;
                if (h != null) h(this, EventArgs.Empty);
            }
            e.Handled = true;
        }
    }
}
