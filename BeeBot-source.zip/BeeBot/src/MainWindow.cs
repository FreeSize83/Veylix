﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using WF = System.Windows.Forms;
using SD = System.Drawing;

namespace BeeBot
{
    public class MainWindow : Window
    {
        Engine engine;
        Settings cfg;
        List<Strategy> strategies;
        Strategy selected;
        bool busy, tuning, tuneCancel, autoMode, reallyExit, autorunOn, trayHintShown;

        StackPanel strategyList, logPanel, timelineRow;
        ScrollViewer logScroll;
        Dictionary<Strategy, ClayButton> cards = new Dictionary<Strategy, ClayButton>();
        Dictionary<Strategy, Ellipse> dots = new Dictionary<Strategy, Ellipse>();
        List<Border> nodes = new List<Border>();
        List<FrameworkElement> timelineItems = new List<FrameworkElement>();

        ClayButton powerBtn, tuneBtn;
        TextBlock powerGlyph, statusText, stratText, uptimeText, tuneText, chipText;
        TextBlock tileStrat, tileIpset, tileGame;
        Ellipse chipDot, autorunDot;
        Border chkDiscord, chkYoutube, chkNet;
        DispatcherTimer timer;
        WF.NotifyIcon tray;

        public MainWindow(bool auto)
        {
            autoMode = auto;
            Title = "BeeBot";
            WindowStyle = WindowStyle.None;
            AllowsTransparency = true;
            Background = Brushes.Transparent;
            ResizeMode = ResizeMode.CanMinimize;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            FontFamily = Theme.Ui;

            double dw = 1204, dh = 764;
            Rect wa = SystemParameters.WorkArea;
            double k = Math.Min(1.0, Math.Min((wa.Width - 16) / dw, (wa.Height - 16) / dh));
            Width = dw * k;
            Height = dh * k;

            try
            {
                engine = new Engine(Engine.Locate());
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось подготовить файлы обхода:\n" + ex.Message, "BeeBot");
                Environment.Exit(1);
            }

            cfg = Settings.Load();
            strategies = engine.LoadStrategies();
            if (strategies.Count == 0)
            {
                MessageBox.Show("Не найдено ни одного файла general*.bat в " + engine.Root, "BeeBot");
                Environment.Exit(1);
            }
            selected = strategies[0];
            foreach (Strategy st in strategies)
            {
                if (st.Display == cfg.LastStrategy) selected = st;
            }

            Grid design = new Grid();
            design.Width = dw;
            design.Height = dh;
            design.Children.Add(BuildRoot());
            Viewbox vb = new Viewbox();
            vb.Stretch = Stretch.Uniform;
            vb.Child = design;
            Content = vb;

            BuildTray();

            engine.Log += delegate(string level, string text) { AddLog(level, text); };
            engine.Exited += delegate
            {
                Dispatcher.BeginInvoke(new Action(delegate
                {
                    AddLog("err", "winws.exe неожиданно завершился.");
                    ResetChecks();
                    RefreshUi();
                }));
            };

            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += delegate { UpdateUptime(); };
            timer.Start();

            Application.Current.SessionEnding += delegate { try { engine.Stop(); } catch { } };
            Application.Current.Exit += delegate { try { engine.Stop(); } catch { } };

            if (autoMode)
            {
                WindowState = WindowState.Minimized;
                ShowInTaskbar = false;
            }
            Loaded += OnLoaded;
        }

        // ====================== построение интерфейса ======================

        FrameworkElement BuildRoot()
        {
            Border root = new Border();
            root.Margin = new Thickness(12);
            root.CornerRadius = new CornerRadius(34);
            LinearGradientBrush bg = new LinearGradientBrush();
            bg.StartPoint = new Point(0, 0);
            bg.EndPoint = new Point(0, 1);
            bg.GradientStops.Add(new GradientStop(Theme.C("#F4D0B0"), 0.0));
            bg.GradientStops.Add(new GradientStop(Theme.C("#E8B8A4"), 0.55));
            bg.GradientStops.Add(new GradientStop(Theme.C("#C6A2B6"), 1.0));
            root.Background = bg;
            root.BorderBrush = Theme.B("#99FFFFFF");
            root.BorderThickness = new Thickness(2);
            root.Effect = Theme.Shadow(28, 8, 0.45);

            Grid g = new Grid();
            g.Margin = new Thickness(18, 16, 18, 14);
            g.RowDefinitions.Add(new RowDefinition());
            RowDefinition dockRow = new RowDefinition();
            dockRow.Height = new GridLength(100);
            g.RowDefinitions.Add(dockRow);

            Plate frame = Theme.Panel("#F3EADF", 30);
            frame.Margin = new Thickness(0, 0, 0, 10);
            frame.Child = BuildFrame();
            Grid.SetRow(frame, 0);
            g.Children.Add(frame);

            FrameworkElement dock = BuildDock();
            Grid.SetRow(dock, 1);
            g.Children.Add(dock);

            root.Child = g;
            return root;
        }

        FrameworkElement BuildFrame()
        {
            Grid g = new Grid();
            g.Margin = new Thickness(16, 8, 16, 16);
            RowDefinition r0 = new RowDefinition();
            r0.Height = new GridLength(46);
            g.RowDefinitions.Add(r0);
            g.RowDefinitions.Add(new RowDefinition());

            FrameworkElement title = BuildTitleBar();
            Grid.SetRow(title, 0);
            g.Children.Add(title);

            Grid main = new Grid();
            Grid.SetRow(main, 1);
            ColumnDefinition c0 = new ColumnDefinition(); c0.Width = new GridLength(232);
            ColumnDefinition c1 = new ColumnDefinition(); c1.Width = new GridLength(14);
            ColumnDefinition c2 = new ColumnDefinition();
            ColumnDefinition c3 = new ColumnDefinition(); c3.Width = new GridLength(14);
            ColumnDefinition c4 = new ColumnDefinition(); c4.Width = new GridLength(272);
            main.ColumnDefinitions.Add(c0);
            main.ColumnDefinitions.Add(c1);
            main.ColumnDefinitions.Add(c2);
            main.ColumnDefinitions.Add(c3);
            main.ColumnDefinitions.Add(c4);

            FrameworkElement left = BuildSidebar();
            Grid.SetColumn(left, 0);
            main.Children.Add(left);

            Grid center = new Grid();
            center.RowDefinitions.Add(new RowDefinition());
            RowDefinition gap = new RowDefinition(); gap.Height = new GridLength(14);
            RowDefinition tl = new RowDefinition(); tl.Height = new GridLength(160);
            center.RowDefinitions.Add(gap);
            center.RowDefinitions.Add(tl);
            FrameworkElement hero = BuildHero();
            Grid.SetRow(hero, 0);
            center.Children.Add(hero);
            FrameworkElement timeline = BuildTimeline();
            Grid.SetRow(timeline, 2);
            center.Children.Add(timeline);
            Grid.SetColumn(center, 2);
            main.Children.Add(center);

            FrameworkElement right = BuildLog();
            Grid.SetColumn(right, 4);
            main.Children.Add(right);

            g.Children.Add(main);
            return g;
        }

        FrameworkElement BuildTitleBar()
        {
            Grid g = new Grid();
            g.Background = Brushes.Transparent;
            g.MouseLeftButtonDown += delegate(object s, MouseButtonEventArgs e)
            {
                if (e.ButtonState == MouseButtonState.Pressed) DragMove();
            };

            StackPanel left = new StackPanel();
            left.Orientation = Orientation.Horizontal;
            left.VerticalAlignment = VerticalAlignment.Center;
            left.Children.Add(Theme.Bee(32));
            TextBlock name = Theme.T("BEE-BOT", 18, Theme.Ink, true);
            name.Margin = new Thickness(10, 0, 0, 0);
            name.VerticalAlignment = VerticalAlignment.Center;
            left.Children.Add(name);
            TextBlock sub = Theme.T("UNBLOCK LAUNCHER", 10, Theme.Muted, true);
            sub.Margin = new Thickness(8, 4, 0, 0);
            sub.VerticalAlignment = VerticalAlignment.Center;
            left.Children.Add(sub);
            g.Children.Add(left);

            StackPanel right = new StackPanel();
            right.Orientation = Orientation.Horizontal;
            right.HorizontalAlignment = HorizontalAlignment.Right;
            right.VerticalAlignment = VerticalAlignment.Center;

            Border chip = new Border();
            chip.Background = Theme.B("#FFF8EF");
            chip.CornerRadius = new CornerRadius(16);
            chip.Padding = new Thickness(14, 6, 14, 6);
            chip.Margin = new Thickness(0, 0, 14, 0);
            chip.BorderBrush = Theme.B("#E8DCCD");
            chip.BorderThickness = new Thickness(1);
            StackPanel cs = new StackPanel();
            cs.Orientation = Orientation.Horizontal;
            chipDot = new Ellipse();
            chipDot.Width = 9; chipDot.Height = 9;
            chipDot.Fill = Theme.B("#DDD2C5");
            chipDot.VerticalAlignment = VerticalAlignment.Center;
            cs.Children.Add(chipDot);
            chipText = Theme.T("Остановлено", 12, Theme.Ink, true);
            chipText.Margin = new Thickness(8, 0, 0, 0);
            cs.Children.Add(chipText);
            chip.Child = cs;
            right.Children.Add(chip);

            ClayButton min = SmallRoundButton(0xE921);
            min.Margin = new Thickness(0, 0, 8, 0);
            min.Click += delegate { WindowState = WindowState.Minimized; };
            right.Children.Add(min);
            ClayButton close = SmallRoundButton(0xE8BB);
            close.Click += delegate { OnCloseClick(); };
            right.Children.Add(close);

            g.Children.Add(right);
            return g;
        }

        ClayButton SmallRoundButton(int glyph)
        {
            ClayButton b = new ClayButton(Theme.G("#FFFCF6", "#EADFD2"), Theme.G("#FFFFFF", "#F2E8DB"), 17);
            b.Width = 34;
            b.Height = 34;
            b.Child = Theme.Icon(glyph, 11, Theme.Ink);
            return b;
        }

        FrameworkElement BuildSidebar()
        {
            Plate panel = Theme.Panel(Theme.Cream, 26);
            Grid g = new Grid();
            g.Margin = new Thickness(12);
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            g.RowDefinitions.Add(new RowDefinition());

            StackPanel head = new StackPanel();
            head.Margin = new Thickness(6, 4, 6, 10);
            head.Children.Add(Theme.T("Стратегии", 17, Theme.Ink, true));
            head.Children.Add(Theme.T("Обходов найдено: " + strategies.Count, 11, Theme.Muted, false));
            Grid.SetRow(head, 0);
            g.Children.Add(head);

            strategyList = new StackPanel();
            for (int i = 0; i < strategies.Count; i++)
            {
                strategyList.Children.Add(MakeCard(strategies[i], i));
            }
            ScrollViewer sv = new ScrollViewer();
            sv.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            sv.Content = strategyList;
            Grid.SetRow(sv, 1);
            g.Children.Add(sv);

            panel.Child = g;
            Select(selected);
            return panel;
        }

        FrameworkElement MakeCard(Strategy s, int idx)
        {
            string[] tileColors = new string[] { "#BFDDB0", "#F6C39B", "#CDBBF0", "#F7E3A1" };
            ClayButton b = new ClayButton(Theme.B("#FFFBF5"), Theme.B("#FFFFFF"), 16);
            b.BorderThickness = new Thickness(2);
            b.BorderBrush = Theme.B("#EADFD1");
            b.Margin = new Thickness(0, 0, 8, 9);
            b.Padding = new Thickness(8);
            b.Effect = Theme.Shadow(8, 2, 0.18);

            Grid g = new Grid();
            ColumnDefinition a = new ColumnDefinition(); a.Width = new GridLength(40);
            ColumnDefinition m = new ColumnDefinition();
            ColumnDefinition z = new ColumnDefinition(); z.Width = GridLength.Auto;
            g.ColumnDefinitions.Add(a);
            g.ColumnDefinitions.Add(m);
            g.ColumnDefinitions.Add(z);

            Border tile = new Border();
            tile.Width = 38; tile.Height = 38;
            tile.CornerRadius = new CornerRadius(12);
            tile.Background = Theme.B(tileColors[idx % tileColors.Length]);
            TextBlock num = Theme.T((idx + 1).ToString(), 15, Theme.Ink, true);
            num.HorizontalAlignment = HorizontalAlignment.Center;
            num.VerticalAlignment = VerticalAlignment.Center;
            tile.Child = num;
            Grid.SetColumn(tile, 0);
            g.Children.Add(tile);

            StackPanel tx = new StackPanel();
            tx.Margin = new Thickness(10, 0, 0, 0);
            tx.VerticalAlignment = VerticalAlignment.Center;
            tx.Children.Add(Theme.T(s.Display, 13, Theme.Ink, true));
            tx.Children.Add(Theme.T(s.Note, 11, s.Warn ? "#D9803C" : Theme.Muted, false));
            Grid.SetColumn(tx, 1);
            g.Children.Add(tx);

            Ellipse dot = new Ellipse();
            dot.Width = 10; dot.Height = 10;
            dot.Fill = Theme.B("#DDD2C5");
            dot.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(dot, 2);
            g.Children.Add(dot);

            b.Child = g;
            b.ToolTip = System.IO.Path.GetFileName(s.BatPath);
            b.Click += delegate { OnPickStrategy(s); };
            cards[s] = b;
            dots[s] = dot;
            return b;
        }

        FrameworkElement BuildHero()
        {
            Plate panel = Theme.Panel(Theme.Cream, 28);
            Grid g = new Grid();
            g.Margin = new Thickness(18);
            ColumnDefinition c0 = new ColumnDefinition(); c0.Width = new GridLength(232);
            g.ColumnDefinitions.Add(c0);
            g.ColumnDefinitions.Add(new ColumnDefinition());

            // --- левая часть: большая кнопка питания ---
            StackPanel left = new StackPanel();
            left.VerticalAlignment = VerticalAlignment.Center;
            left.HorizontalAlignment = HorizontalAlignment.Center;

            Grid well = new Grid();
            well.Width = 190; well.Height = 190;
            Border ring = new Border();
            ring.CornerRadius = new CornerRadius(95);
            ring.Background = Theme.G("#E4D7C8", "#FAF4EB");
            ring.BorderBrush = Theme.B("#FFFFFF");
            ring.BorderThickness = new Thickness(2);
            well.Children.Add(ring);

            powerBtn = new ClayButton(Theme.G("#FFFBF4", "#E9DDCF"), Theme.G("#FFFFFF", "#EFE4D6"), 72);
            powerBtn.Width = 144; powerBtn.Height = 144;
            powerBtn.Effect = Theme.Shadow(18, 6, 0.30);
            powerGlyph = Theme.Icon(0xE7E8, 58, Theme.Purple);
            powerBtn.Child = powerGlyph;
            powerBtn.Click += delegate { OnPower(); };
            well.Children.Add(powerBtn);
            left.Children.Add(well);

            statusText = Theme.T("Обход выключен", 19, Theme.Ink, true);
            statusText.HorizontalAlignment = HorizontalAlignment.Center;
            statusText.Margin = new Thickness(0, 14, 0, 0);
            left.Children.Add(statusText);
            stratText = Theme.T("", 13, Theme.Muted, false);
            stratText.HorizontalAlignment = HorizontalAlignment.Center;
            stratText.Margin = new Thickness(0, 3, 0, 0);
            left.Children.Add(stratText);
            uptimeText = Theme.T("", 12, Theme.Muted, false);
            uptimeText.HorizontalAlignment = HorizontalAlignment.Center;
            uptimeText.Margin = new Thickness(0, 2, 0, 0);
            left.Children.Add(uptimeText);
            Grid.SetColumn(left, 0);
            g.Children.Add(left);

            // --- правая часть: записка и плитки режимов ---
            StackPanel right = new StackPanel();
            right.VerticalAlignment = VerticalAlignment.Center;
            right.Children.Add(BuildNote());

            TextBlock lbl = Theme.T("Режимы (нажмите, чтобы переключить)", 11, Theme.Muted, true);
            lbl.Margin = new Thickness(6, 16, 0, 6);
            right.Children.Add(lbl);

            Grid tiles = new Grid();
            tiles.ColumnDefinitions.Add(new ColumnDefinition());
            tiles.ColumnDefinitions.Add(new ColumnDefinition());
            tiles.ColumnDefinitions.Add(new ColumnDefinition());

            ClayButton t1 = MakeTile("#CFE9C2", "#A9D497", 0xE8FD, "Стратегия", out tileStrat);
            t1.Click += delegate { OnNextStrategy(); };
            Grid.SetColumn(t1, 0);
            tiles.Children.Add(t1);

            ClayButton t2 = MakeTile("#FAD0AB", "#F0A874", 0xE774, "IPSet", out tileIpset);
            t2.Click += delegate { OnIpset(); };
            Grid.SetColumn(t2, 1);
            tiles.Children.Add(t2);

            ClayButton t3 = MakeTile("#D8CBF4", "#B7A0E8", 0xE7FC, "Игровой фильтр", out tileGame);
            t3.Click += delegate { OnGame(); };
            Grid.SetColumn(t3, 2);
            tiles.Children.Add(t3);

            right.Children.Add(tiles);
            Grid.SetColumn(right, 1);
            g.Children.Add(right);

            panel.Child = g;
            return panel;
        }

        ClayButton MakeTile(string c1, string c2, int glyph, string caption, out TextBlock value)
        {
            ClayButton b = new ClayButton(Theme.G(c1, c2), null, 22);
            b.Height = 104;
            b.Margin = new Thickness(4, 0, 4, 0);
            StackPanel sp = new StackPanel();
            sp.VerticalAlignment = VerticalAlignment.Center;
            sp.HorizontalAlignment = HorizontalAlignment.Center;
            TextBlock ic = Theme.Icon(glyph, 22, Theme.Ink);
            ic.Opacity = 0.6;
            sp.Children.Add(ic);
            value = Theme.T("", 17, Theme.Ink, true);
            value.HorizontalAlignment = HorizontalAlignment.Center;
            value.Margin = new Thickness(0, 6, 0, 0);
            sp.Children.Add(value);
            TextBlock cap = Theme.T(caption, 11, Theme.Ink, false);
            cap.Opacity = 0.7;
            cap.HorizontalAlignment = HorizontalAlignment.Center;
            sp.Children.Add(cap);
            b.Child = sp;
            return b;
        }

        FrameworkElement BuildNote()
        {
            Border note = new Border();
            note.Background = Theme.G("#FCEBA9", "#F7DF86");
            note.CornerRadius = new CornerRadius(10);
            note.Padding = new Thickness(16, 12, 16, 12);
            note.Margin = new Thickness(6, 0, 6, 0);
            note.Effect = Theme.Shadow(14, 4, 0.28);
            note.RenderTransformOrigin = new Point(0.5, 0.5);
            note.RenderTransform = new RotateTransform(-1.6);

            StackPanel sp = new StackPanel();
            sp.Children.Add(Theme.T("Проверка доступа", 14, Theme.Ink, true));
            TextBlock hint = Theme.T("Быстрый тест после запуска", 11, "#8A7A55", false);
            hint.Margin = new Thickness(0, 0, 0, 8);
            sp.Children.Add(hint);

            chkDiscord = AddCheckRow(sp, "Discord");
            chkYoutube = AddCheckRow(sp, "YouTube");
            chkNet = AddCheckRow(sp, "Интернет (Google)");

            ClayButton test = new ClayButton(Theme.G("#FFF3C2", "#F1D46F"), Theme.G("#FFF8D8", "#F5DB80"), 13);
            test.Width = 112;
            test.Height = 28;
            test.HorizontalAlignment = HorizontalAlignment.Left;
            test.Margin = new Thickness(0, 8, 0, 0);
            test.Effect = Theme.Shadow(6, 2, 0.15);
            TextBlock tt = Theme.T("Проверить", 12, Theme.Ink, true);
            tt.HorizontalAlignment = HorizontalAlignment.Center;
            tt.VerticalAlignment = VerticalAlignment.Center;
            test.Child = tt;
            test.Click += delegate { RunAccessTest(); };
            sp.Children.Add(test);

            note.Child = sp;
            return note;
        }

        Border AddCheckRow(StackPanel parent, string label)
        {
            Grid row = new Grid();
            row.Margin = new Thickness(0, 3, 0, 3);
            ColumnDefinition a = new ColumnDefinition(); a.Width = new GridLength(28);
            row.ColumnDefinitions.Add(a);
            row.ColumnDefinitions.Add(new ColumnDefinition());
            Border badge = Theme.Badge(22);
            Grid.SetColumn(badge, 0);
            row.Children.Add(badge);
            TextBlock t = Theme.T(label, 13, Theme.Ink, false);
            t.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(t, 1);
            row.Children.Add(t);
            parent.Children.Add(row);
            return badge;
        }

        FrameworkElement BuildTimeline()
        {
            Plate panel = Theme.Panel(Theme.Cream, 26);
            Grid g = new Grid();
            g.Margin = new Thickness(16, 12, 16, 10);
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            g.RowDefinitions.Add(new RowDefinition());

            Grid head = new Grid();
            head.ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinition hc = new ColumnDefinition(); hc.Width = GridLength.Auto;
            head.ColumnDefinitions.Add(hc);

            StackPanel ht = new StackPanel();
            ht.Children.Add(Theme.T("Автоподбор стратегии", 16, Theme.Ink, true));
            ht.Children.Add(Theme.T("Перебирает обходы по очереди и проверяет Discord + YouTube", 11, Theme.Muted, false));
            Grid.SetColumn(ht, 0);
            head.Children.Add(ht);

            tuneBtn = new ClayButton(Theme.G("#AE95EE", "#8B6BD6"), Theme.G("#B9A3F2", "#9578DD"), 18);
            tuneBtn.Width = 170;
            tuneBtn.Height = 36;
            tuneText = Theme.T("Запустить подбор", 13, "#FFFFFF", true);
            tuneText.HorizontalAlignment = HorizontalAlignment.Center;
            tuneText.VerticalAlignment = VerticalAlignment.Center;
            tuneBtn.Child = tuneText;
            tuneBtn.Click += delegate { OnTune(); };
            Grid.SetColumn(tuneBtn, 1);
            head.Children.Add(tuneBtn);
            Grid.SetRow(head, 0);
            g.Children.Add(head);

            timelineRow = new StackPanel();
            timelineRow.Orientation = Orientation.Horizontal;
            for (int i = 0; i < strategies.Count; i++)
            {
                Grid item = new Grid();
                item.Width = 68;
                RowDefinition r0 = new RowDefinition(); r0.Height = new GridLength(34);
                item.RowDefinitions.Add(r0);
                item.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

                Rectangle line = new Rectangle();
                line.Height = 3;
                line.Fill = Theme.B("#DCCFC0");
                line.VerticalAlignment = VerticalAlignment.Center;
                line.Margin = new Thickness(i == 0 ? 34 : 0, 0, i == strategies.Count - 1 ? 34 : 0, 0);
                Grid.SetRow(line, 0);
                item.Children.Add(line);

                Border dot = Theme.Badge(24);
                dot.HorizontalAlignment = HorizontalAlignment.Center;
                dot.VerticalAlignment = VerticalAlignment.Center;
                Grid.SetRow(dot, 0);
                item.Children.Add(dot);
                nodes.Add(dot);

                TextBlock lb = Theme.T(ShortName(strategies[i].Display), 10.5, Theme.Muted, true);
                lb.HorizontalAlignment = HorizontalAlignment.Center;
                lb.TextAlignment = TextAlignment.Center;
                lb.TextWrapping = TextWrapping.Wrap;
                lb.MaxWidth = 62;
                Grid.SetRow(lb, 1);
                item.Children.Add(lb);
                item.ToolTip = strategies[i].Display;

                timelineRow.Children.Add(item);
                timelineItems.Add(item);
            }
            ScrollViewer sv = new ScrollViewer();
            sv.HorizontalScrollBarVisibility = ScrollBarVisibility.Auto;
            sv.VerticalScrollBarVisibility = ScrollBarVisibility.Disabled;
            sv.Content = timelineRow;
            sv.Margin = new Thickness(0, 8, 0, 0);
            Grid.SetRow(sv, 1);
            g.Children.Add(sv);

            panel.Child = g;
            return panel;
        }

        static string ShortName(string d)
        {
            string s = d.Replace("FAKE TLS AUTO", "FTA").Replace("SIMPLE FAKE", "SF");
            if (s == "general") s = "main";
            return s;
        }

        FrameworkElement BuildLog()
        {
            Plate panel = Theme.Panel(Theme.Cream, 26);
            Grid g = new Grid();
            g.Margin = new Thickness(14, 12, 14, 12);
            g.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            g.RowDefinitions.Add(new RowDefinition());

            Grid head = new Grid();
            head.Margin = new Thickness(2, 0, 0, 8);
            head.ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinition hc = new ColumnDefinition(); hc.Width = GridLength.Auto;
            head.ColumnDefinitions.Add(hc);
            TextBlock ttl = Theme.T("Журнал", 17, Theme.Ink, true);
            ttl.VerticalAlignment = VerticalAlignment.Center;
            head.Children.Add(ttl);
            ClayButton clear = SmallRoundButton(0xE74D);
            clear.Width = 30; clear.Height = 30;
            clear.ToolTip = "Очистить журнал";
            clear.Click += delegate { logPanel.Children.Clear(); };
            Grid.SetColumn(clear, 1);
            head.Children.Add(clear);
            Grid.SetRow(head, 0);
            g.Children.Add(head);

            logPanel = new StackPanel();
            logScroll = new ScrollViewer();
            logScroll.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            logScroll.Content = logPanel;
            Grid.SetRow(logScroll, 1);
            g.Children.Add(logScroll);

            panel.Child = g;
            return panel;
        }

        FrameworkElement BuildDock()
        {
            Border bar = new Border();
            bar.Background = Theme.B("#55FFFFFF");
            bar.BorderBrush = Theme.B("#88FFFFFF");
            bar.BorderThickness = new Thickness(1.5);
            bar.CornerRadius = new CornerRadius(30);
            bar.Padding = new Thickness(10, 8, 10, 8);
            bar.HorizontalAlignment = HorizontalAlignment.Center;
            bar.VerticalAlignment = VerticalAlignment.Center;

            StackPanel sp = new StackPanel();
            sp.Orientation = Orientation.Horizontal;

            ClayButton autorun = DockTile(0xE768, "Автозапуск", "#8B6BD6");
            autorunDot = new Ellipse();
            autorunDot.Width = 10; autorunDot.Height = 10;
            autorunDot.Fill = Theme.B("#DDD2C5");
            autorunDot.HorizontalAlignment = HorizontalAlignment.Right;
            autorunDot.VerticalAlignment = VerticalAlignment.Top;
            autorunDot.Margin = new Thickness(0, 8, 8, 0);
            ((Grid)autorun.Child).Children.Add(autorunDot);
            autorun.ToolTip = "Запускать вместе с Windows (скрыто, в трее)";
            autorun.Click += delegate { OnAutorun(); };
            sp.Children.Add(autorun);

            ClayButton upd = DockTile(0xE895, "Обновить IPSet", "#F0A35E");
            upd.ToolTip = "Скачать свежий список IP-адресов";
            upd.Click += delegate { OnUpdateIpset(); };
            sp.Children.Add(upd);

            ClayButton dom = DockTile(0xE8A5, "Мои домены", "#7DBE6B");
            dom.ToolTip = "list-general-user.txt: свои домены для обхода";
            dom.Click += delegate { OnOpenUserList("list-general-user.txt"); };
            sp.Children.Add(dom);

            ClayButton exc = DockTile(0xE711, "Исключения", "#E5B94F");
            exc.ToolTip = "list-exclude-user.txt: домены, которые не трогать";
            exc.Click += delegate { OnOpenUserList("list-exclude-user.txt"); };
            sp.Children.Add(exc);

            ClayButton fol = DockTile(0xE838, "Папка", "#7FA8E0");
            fol.ToolTip = "Открыть папку с файлами обхода";
            fol.Click += delegate { OpenPath("explorer.exe", engine.Root); };
            sp.Children.Add(fol);

            ClayButton tr = DockTile(0xE921, "В трей", "#C79AD8");
            tr.ToolTip = "Скрыть окно (обход продолжит работать)";
            tr.Click += delegate { HideToTray(); };
            sp.Children.Add(tr);

            ClayButton ex = DockTile(0xE8BB, "Выход", "#E58C84");
            ex.ToolTip = "Остановить обход и закрыть программу";
            ex.Click += delegate { ExitApp(); };
            sp.Children.Add(ex);

            bar.Child = sp;
            return bar;
        }

        ClayButton DockTile(int glyph, string label, string colorHex)
        {
            ClayButton b = new ClayButton(Theme.G("#FFFCF6", "#EBDFD2"), Theme.G("#FFFFFF", "#F2E8DB"), 20);
            b.Width = 90;
            b.Height = 76;
            b.Margin = new Thickness(5, 0, 5, 0);
            Grid g = new Grid();
            StackPanel sp = new StackPanel();
            sp.VerticalAlignment = VerticalAlignment.Center;
            sp.HorizontalAlignment = HorizontalAlignment.Center;
            Border circle = new Border();
            circle.Width = 36;
            circle.Height = 36;
            circle.CornerRadius = new CornerRadius(12);
            circle.Background = Theme.B(colorHex);
            circle.Child = Theme.Icon(glyph, 17, "#FFFFFF");
            sp.Children.Add(circle);
            TextBlock t = Theme.T(label, 10.5, Theme.Ink, true);
            t.HorizontalAlignment = HorizontalAlignment.Center;
            t.Margin = new Thickness(0, 5, 0, 0);
            sp.Children.Add(t);
            g.Children.Add(sp);
            b.Child = g;
            return b;
        }

        // ====================== трей ======================

        void BuildTray()
        {
            tray = new WF.NotifyIcon();
            try
            {
                tray.Icon = SD.Icon.ExtractAssociatedIcon(Assembly.GetExecutingAssembly().Location);
            }
            catch
            {
                tray.Icon = SD.SystemIcons.Application;
            }
            tray.Text = "BeeBot";
            WF.ContextMenuStrip menu = new WF.ContextMenuStrip();
            menu.Items.Add("Открыть окно", null, delegate(object s, EventArgs e) { ShowFromTray(); });
            menu.Items.Add("Включить / выключить", null, delegate(object s, EventArgs e) { OnPower(); });
            menu.Items.Add("Выход", null, delegate(object s, EventArgs e) { ExitApp(); });
            tray.ContextMenuStrip = menu;
            tray.DoubleClick += delegate(object s, EventArgs e) { ShowFromTray(); };
            tray.Visible = true;
        }

        void ShowFromTray()
        {
            Show();
            ShowInTaskbar = true;
            WindowState = WindowState.Normal;
            Activate();
        }

        void HideToTray()
        {
            Hide();
            if (!trayHintShown)
            {
                trayHintShown = true;
                try { tray.ShowBalloonTip(2500, "BeeBot", "Работает в трее. Двойной клик по значку — открыть окно.", WF.ToolTipIcon.Info); }
                catch { }
            }
        }

        void OnCloseClick()
        {
            if (engine.IsRunning && !tuning) HideToTray();
            else ExitApp();
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            if (!reallyExit)
            {
                e.Cancel = true;
                OnCloseClick();
                return;
            }
            base.OnClosing(e);
        }

        void ExitApp()
        {
            reallyExit = true;
            try { tray.Visible = false; tray.Dispose(); } catch { }
            try { engine.Stop(); } catch { }
            Application.Current.Shutdown();
        }

        // ====================== состояние и журнал ======================

        void Select(Strategy s)
        {
            selected = s;
            foreach (KeyValuePair<Strategy, ClayButton> kv in cards)
            {
                kv.Value.BorderBrush = Theme.B(kv.Key == s ? Theme.Purple : "#EADFD1");
            }
            if (tileStrat != null) tileStrat.Text = s.Display;
        }

        static string IpsetLabel(string m)
        {
            if (m == "none") return "Выкл";
            if (m == "loaded") return "Список";
            return "Все IP";
        }

        static string GameLabel(string m)
        {
            if (m == "all") return "TCP+UDP";
            if (m == "tcp") return "TCP";
            if (m == "udp") return "UDP";
            return "Выкл";
        }

        void RefreshUi()
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.BeginInvoke(new Action(RefreshUi));
                return;
            }
            bool run = engine.IsRunning;
            Strategy cur = engine.Current;
            string name = cur != null ? cur.Display : (selected != null ? selected.Display : "—");

            if (busy || tuning)
            {
                powerBtn.SetBrushes(Theme.G("#FCD9B4", "#F0A35E"), null);
                powerGlyph.Foreground = Theme.B("#FFFFFF");
                statusText.Text = tuning ? "Подбираю стратегию…" : "Подождите…";
                statusText.Foreground = Theme.B("#D9803C");
                chipDot.Fill = Theme.B(Theme.Orange);
                chipText.Text = tuning ? "Автоподбор" : "Работаю…";
            }
            else if (run)
            {
                powerBtn.SetBrushes(Theme.G("#CFEEC0", "#8FCB7A"), Theme.G("#D8F3CB", "#9BD487"));
                powerGlyph.Foreground = Theme.B("#2F6B2A");
                statusText.Text = "Обход работает";
                statusText.Foreground = Theme.B("#4E9A3F");
                chipDot.Fill = Theme.B(Theme.Green);
                chipText.Text = "Работает · " + name;
            }
            else
            {
                powerBtn.SetBrushes(Theme.G("#FFFBF4", "#E9DDCF"), Theme.G("#FFFFFF", "#EFE4D6"));
                powerGlyph.Foreground = Theme.B(Theme.Purple);
                statusText.Text = "Обход выключен";
                statusText.Foreground = Theme.B(Theme.Ink);
                chipDot.Fill = Theme.B("#DDD2C5");
                chipText.Text = "Остановлено";
            }
            powerBtn.IsEnabled = !tuning;
            stratText.Text = "Стратегия: " + name;
            tileStrat.Text = name;
            tileIpset.Text = IpsetLabel(engine.GetIpsetMode());
            tileGame.Text = GameLabel(engine.GameMode);

            foreach (KeyValuePair<Strategy, Ellipse> kv in dots)
            {
                bool on = run && cur != null && object.ReferenceEquals(cur, kv.Key);
                kv.Value.Fill = Theme.B(on ? Theme.Green : "#DDD2C5");
            }
            try { tray.Text = run ? "BeeBot — работает: " + name : "BeeBot — остановлен"; } catch { }
            UpdateUptime();
        }

        void UpdateUptime()
        {
            if (engine != null && engine.IsRunning)
            {
                TimeSpan t = DateTime.Now - engine.StartedAt;
                uptimeText.Text = "Время работы  " + string.Format("{0:00}:{1:00}:{2:00}", (int)t.TotalHours, t.Minutes, t.Seconds);
            }
            else
            {
                uptimeText.Text = "";
            }
        }

        void UpdateAutorunDot()
        {
            autorunDot.Fill = Theme.B(autorunOn ? Theme.Green : "#DDD2C5");
        }

        void ResetChecks()
        {
            Theme.ApplyBadge(chkDiscord, 0);
            Theme.ApplyBadge(chkYoutube, 0);
            Theme.ApplyBadge(chkNet, 0);
        }

        void AddLog(string level, string text)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.BeginInvoke(new Action(delegate { AddLog(level, text); }));
                return;
            }
            if (logPanel == null) return;
            if (text.Length > 220) text = text.Substring(0, 220) + "…";

            string color, mark;
            if (level == "ok") { color = Theme.Green; mark = "✓"; }
            else if (level == "err") { color = Theme.Red; mark = "✕"; }
            else if (level == "warn") { color = Theme.Orange; mark = "!"; }
            else if (level == "proc") { color = "#CFC4B8"; mark = "›"; }
            else { color = "#B49CEB"; mark = "i"; }

            StackPanel entry = new StackPanel();
            entry.Margin = new Thickness(0, 0, 6, 10);
            entry.Children.Add(Theme.T(DateTime.Now.ToString("HH:mm:ss"), 10, Theme.Muted, false));

            Grid row = new Grid();
            row.Margin = new Thickness(0, 2, 0, 0);
            ColumnDefinition a = new ColumnDefinition(); a.Width = new GridLength(28);
            row.ColumnDefinitions.Add(a);
            row.ColumnDefinitions.Add(new ColumnDefinition());

            Border badge = new Border();
            badge.Width = 22; badge.Height = 22;
            badge.CornerRadius = new CornerRadius(11);
            badge.Background = Theme.B(color);
            badge.VerticalAlignment = VerticalAlignment.Top;
            badge.HorizontalAlignment = HorizontalAlignment.Left;
            TextBlock mk = Theme.T(mark, 12, "#FFFFFF", true);
            mk.HorizontalAlignment = HorizontalAlignment.Center;
            mk.VerticalAlignment = VerticalAlignment.Center;
            badge.Child = mk;
            Grid.SetColumn(badge, 0);
            row.Children.Add(badge);

            TextBlock tx = Theme.T(text, 12, level == "proc" ? Theme.Muted : Theme.Ink, false);
            tx.TextWrapping = TextWrapping.Wrap;
            tx.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(tx, 1);
            row.Children.Add(tx);
            entry.Children.Add(row);

            logPanel.Children.Add(entry);
            while (logPanel.Children.Count > 150) logPanel.Children.RemoveAt(0);
            logScroll.ScrollToEnd();
        }

        void OpenPath(string exe, string arg)
        {
            try { Process.Start(exe, "\"" + arg + "\""); }
            catch (Exception ex) { AddLog("err", ex.Message); }
        }

        // ====================== действия ======================

        async void OnLoaded(object sender, RoutedEventArgs e)
        {
            try
            {
                RefreshUi();
                AddLog("info", "Готово. Выберите стратегию слева и нажмите кнопку питания.");
                AddLog("info", "Файлы обхода: " + engine.Root);
                if (engine.ExternalRunning())
                    AddLog("warn", "Уже запущен другой winws.exe (из .bat или службы zapret). При старте он будет остановлен.");
                autorunOn = await Task.Run(() => Engine.IsAutorun());
                UpdateAutorunDot();
                if (autoMode)
                {
                    Hide();
                    await StartAsync(selected);
                }
            }
            catch (Exception ex)
            {
                AddLog("err", ex.Message);
            }
        }

        async void OnPower()
        {
            try
            {
                if (busy || tuning) return;
                if (engine.IsRunning) await StopAsync();
                else await StartAsync(selected);
            }
            catch (Exception ex)
            {
                busy = false;
                AddLog("err", ex.Message);
                RefreshUi();
            }
        }

        async Task<bool> StartAsync(Strategy s)
        {
            busy = true;
            RefreshUi();
            AddLog("info", "Запускаю стратегию " + s.Display + "…");
            bool ok = await Task.Run(() => engine.Start(s));
            if (ok)
            {
                await Task.Delay(1500);
                if (!engine.IsRunning)
                {
                    ok = false;
                    AddLog("err", "winws.exe сразу завершился. Проверьте: запуск от администратора, нет ли другого обхода/VPN, не удалил ли антивирус файлы.");
                }
            }
            busy = false;
            if (ok)
            {
                cfg.LastStrategy = s.Display;
                cfg.Save();
                AddLog("ok", "Обход работает: " + s.Display);
            }
            RefreshUi();
            if (ok) RunAccessTest();
            return ok;
        }

        async Task StopAsync()
        {
            busy = true;
            RefreshUi();
            await Task.Run(() => engine.Stop());
            busy = false;
            AddLog("info", "Обход остановлен.");
            ResetChecks();
            RefreshUi();
        }

        async void OnPickStrategy(Strategy s)
        {
            try
            {
                if (busy || tuning) return;
                Select(s);
                if (engine.IsRunning) await StartAsync(s);
                else RefreshUi();
            }
            catch (Exception ex)
            {
                busy = false;
                AddLog("err", ex.Message);
                RefreshUi();
            }
        }

        void OnNextStrategy()
        {
            if (busy || tuning) return;
            int i = strategies.IndexOf(selected);
            i = (i + 1) % strategies.Count;
            OnPickStrategy(strategies[i]);
            cards[strategies[i]].BringIntoView();
        }

        async void OnIpset()
        {
            try
            {
                if (busy || tuning) return;
                string err = engine.CycleIpset();
                if (err != null) { AddLog("err", err); return; }
                AddLog("info", "IPSet: " + IpsetLabel(engine.GetIpsetMode()));
                RefreshUi();
                if (engine.IsRunning)
                {
                    Strategy cur = engine.Current != null ? engine.Current : selected;
                    AddLog("info", "Перезапускаю обход, чтобы применить изменение…");
                    await StartAsync(cur);
                }
            }
            catch (Exception ex)
            {
                busy = false;
                AddLog("err", ex.Message);
                RefreshUi();
            }
        }

        async void OnGame()
        {
            try
            {
                if (busy || tuning) return;
                engine.SetGameMode(engine.NextGameMode());
                AddLog("info", "Игровой фильтр: " + GameLabel(engine.GameMode));
                RefreshUi();
                if (engine.IsRunning)
                {
                    Strategy cur = engine.Current != null ? engine.Current : selected;
                    AddLog("info", "Перезапускаю обход, чтобы применить изменение…");
                    await StartAsync(cur);
                }
            }
            catch (Exception ex)
            {
                busy = false;
                AddLog("err", ex.Message);
                RefreshUi();
            }
        }

        async void OnUpdateIpset()
        {
            try
            {
                if (busy || tuning) return;
                busy = true;
                RefreshUi();
                AddLog("info", "Скачиваю свежий список IPSet…");
                string err = await Task.Run(() => engine.UpdateIpset());
                busy = false;
                if (err != null)
                {
                    AddLog("err", "Не удалось обновить IPSet: " + err);
                    RefreshUi();
                    return;
                }
                AddLog("ok", "IPSet обновлён (режим «Список»).");
                RefreshUi();
                if (engine.IsRunning)
                {
                    Strategy cur = engine.Current != null ? engine.Current : selected;
                    await StartAsync(cur);
                }
            }
            catch (Exception ex)
            {
                busy = false;
                AddLog("err", ex.Message);
                RefreshUi();
            }
        }

        async void OnAutorun()
        {
            try
            {
                if (busy || tuning) return;
                bool turnOn = !autorunOn;
                string exe = Assembly.GetExecutingAssembly().Location;
                string err = await Task.Run(() => Engine.SetAutorun(turnOn, exe));
                if (err != null)
                {
                    AddLog("err", "Автозапуск: " + err);
                    return;
                }
                autorunOn = turnOn;
                UpdateAutorunDot();
                AddLog("ok", turnOn
                    ? "Автозапуск включён: при входе в Windows BeeBot запустит последнюю стратегию в трее."
                    : "Автозапуск выключен.");
            }
            catch (Exception ex)
            {
                AddLog("err", ex.Message);
            }
        }

        void OnOpenUserList(string fileName)
        {
            try
            {
                engine.EnsureUserLists();
                OpenPath("notepad.exe", System.IO.Path.Combine(engine.Lists, fileName));
                AddLog("info", "После сохранения файла перезапустите обход (кнопка питания).");
            }
            catch (Exception ex)
            {
                AddLog("err", ex.Message);
            }
        }

        async void RunAccessTest()
        {
            try
            {
                Theme.ApplyBadge(chkDiscord, 1);
                Theme.ApplyBadge(chkYoutube, 1);
                Theme.ApplyBadge(chkNet, 1);
                await Task.Delay(800);
                Task<bool> d = Engine.TestUrl("https://discord.com", 7000);
                Task<bool> y = Engine.TestUrl("https://www.youtube.com", 7000);
                Task<bool> n = Engine.TestUrl("https://www.google.com", 7000);
                bool[] r = await Task.WhenAll(d, y, n);
                Theme.ApplyBadge(chkDiscord, r[0] ? 2 : 3);
                Theme.ApplyBadge(chkYoutube, r[1] ? 2 : 3);
                Theme.ApplyBadge(chkNet, r[2] ? 2 : 3);
                string res = "Проверка: Discord " + (r[0] ? "✓" : "✕") + ", YouTube " + (r[1] ? "✓" : "✕") + ", интернет " + (r[2] ? "✓" : "✕");
                AddLog((r[0] && r[1]) ? "ok" : "warn", res);
                if (!(r[0] && r[1]) && engine.IsRunning)
                    AddLog("info", "Если что-то не открывается — выберите другую стратегию или запустите автоподбор.");
            }
            catch (Exception ex)
            {
                AddLog("err", ex.Message);
            }
        }

        async void OnTune()
        {
            try
            {
                if (tuning)
                {
                    tuneCancel = true;
                    tuneText.Text = "Останавливаю…";
                    return;
                }
                if (busy) return;

                tuning = true;
                tuneCancel = false;
                tuneText.Text = "Остановить подбор";
                foreach (Border nd in nodes) Theme.ApplyBadge(nd, 0);
                ResetChecks();
                RefreshUi();
                AddLog("info", "Автоподбор: пробую стратегии по очереди (Discord + YouTube).");

                Strategy winner = null;
                for (int i = 0; i < strategies.Count; i++)
                {
                    if (tuneCancel) break;
                    Strategy s = strategies[i];
                    Theme.ApplyBadge(nodes[i], 1);
                    timelineItems[i].BringIntoView();
                    Select(s);

                    bool ok = await Task.Run(() => engine.Start(s));
                    if (ok)
                    {
                        await Task.Delay(3500);
                        ok = engine.IsRunning;
                    }
                    if (ok && !tuneCancel)
                    {
                        bool dOk = await Engine.TestUrl("https://discord.com", 6000);
                        bool yOk = await Engine.TestUrl("https://www.youtube.com", 6000);
                        ok = dOk && yOk;
                        AddLog(ok ? "ok" : "warn", s.Display + ": Discord " + (dOk ? "✓" : "✕") + ", YouTube " + (yOk ? "✓" : "✕"));
                    }
                    else
                    {
                        ok = false;
                    }
                    Theme.ApplyBadge(nodes[i], ok ? 2 : 3);
                    RefreshUi();
                    if (ok) { winner = s; break; }
                }

                tuning = false;
                tuneText.Text = "Запустить подбор";
                if (winner != null)
                {
                    Select(winner);
                    cfg.LastStrategy = winner.Display;
                    cfg.Save();
                    AddLog("ok", "Найдена рабочая стратегия: " + winner.Display + ". Она уже запущена.");
                    RefreshUi();
                    RunAccessTest();
                }
                else
                {
                    await Task.Run(() => engine.Stop());
                    AddLog(tuneCancel ? "info" : "warn",
                        tuneCancel ? "Автоподбор остановлен."
                                   : "Ни одна стратегия не прошла проверку. Попробуйте режим IPSet/игровой фильтр или проверьте интернет.");
                    RefreshUi();
                }
            }
            catch (Exception ex)
            {
                tuning = false;
                busy = false;
                tuneText.Text = "Запустить подбор";
                AddLog("err", ex.Message);
                RefreshUi();
            }
        }
    }
}
